' ============================================================
' OficinaApp.vbs - abre o OficinaApp SEM janela preta.
' E o que o atalho "OficinaApp" da Area de Trabalho chama.
'  - Ja esta aberto? So abre o navegador.
'  - Primeira vez (ou dependencias mudaram)? Roda o iniciar.bat, que instala
'    e depois chama este arquivo de novo.
'  - Senao: sobe o servidor com pythonw.exe (sem console) e abre o navegador.
' Para fechar: botao "Fechar o sistema" no menu lateral. Emergencia
' (navegador travado): "Fechar OficinaApp.bat" na pasta do sistema.
' Para ver as mensagens: iniciar.bat console
' ============================================================
Option Explicit
Dim sh, fso, pasta, pyw, url, env, i, senhaTxt, pacote, prep, app

Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
pasta = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = pasta
url = "http://127.0.0.1:5000/"

If Respondendo() Then
  sh.Run url
  WScript.Quit
End If

' Pacote Windows (instalador): traz o proprio Python em python\ e ja vem com
' tudo instalado. Instalacao pelo codigo-fonte: usa o .venv do iniciar.bat.
pacote = fso.FileExists(pasta & "\python\pythonw.exe")
If pacote Then
  pyw = pasta & "\python\pythonw.exe"
Else
  pyw = pasta & "\.venv\Scripts\pythonw.exe"
End If
' (VBScript nao para no primeiro Or: por isso os If um dentro do outro.)
If Not pacote Then
  If Not fso.FileExists(pyw) Or Not fso.FileExists(pasta & "\.env") Or Not DependenciasEmDia() Then
    If WScript.Arguments.Count > 0 Then
      ' Veio do iniciar.bat e mesmo assim falta algo: nao entra em laco.
      MsgBox "A instalacao nao terminou. Rode  iniciar.bat console  para ver o erro.", vbExclamation, "OficinaApp"
      WScript.Quit
    End If
    sh.Run """" & pasta & "\iniciar.bat""", 1, False
    WScript.Quit
  End If
End If

If Not fso.FolderExists(pasta & "\instance") Then fso.CreateFolder(pasta & "\instance")
' Codigo compilado (.pyc) no pacote: roda o .pyc quando o .py nao vem junto.
prep = "scripts\preparar_env.py"
If Not fso.FileExists(pasta & "\" & prep) Then prep = "scripts\preparar_env.pyc"
app = "app.py"
If Not fso.FileExists(pasta & "\" & app) Then app = "app.pyc"
If pacote Then
  sh.Run """" & pyw & """ " & prep & " --pacote", 0, True
Else
  sh.Run """" & pyw & """ " & prep, 0, True
End If

Set env = sh.Environment("PROCESS")
env("ABRIR_NAVEGADOR") = "1"
env("OFICINA_LANCADOR") = "1"
sh.Run """" & pyw & """ " & app, 0, False

For i = 1 To 60
  WScript.Sleep 500
  If Respondendo() Then Exit For
Next

If Not Respondendo() Then
  MsgBox "O OficinaApp nao conseguiu abrir." & vbCrLf & vbCrLf & _
         "O motivo fica no arquivo  instance\logs\servidor.log" & vbCrLf & _
         "dentro da pasta do sistema:" & vbCrLf & pasta, _
         vbExclamation, "OficinaApp"
  WScript.Quit
End If

' Primeira vez (ou senha redefinida): mostra a senha provisoria no Bloco de Notas.
senhaTxt = pasta & "\instance\SENHA-INICIAL.txt"
If fso.FileExists(senhaTxt) Then
  If DateDiff("s", fso.GetFile(senhaTxt).DateLastModified, Now) < 120 Then
    sh.Run "notepad.exe """ & senhaTxt & """", 1, False
  End If
End If

Function Respondendo()
  Dim h
  Respondendo = False
  On Error Resume Next
  Set h = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  h.setTimeouts 1000, 1000, 1000, 1000
  h.Open "GET", url & "health", False
  h.Send
  If Err.Number = 0 Then Respondendo = (h.Status > 0)
  Err.Clear
  On Error GoTo 0
End Function

Function DependenciasEmDia()
  Dim a, b
  DependenciasEmDia = False
  a = pasta & "\requirements.txt"
  b = pasta & "\.venv\requisitos-instalados.txt"
  If Not fso.FileExists(b) Then Exit Function
  DependenciasEmDia = (fso.OpenTextFile(a, 1).ReadAll() = fso.OpenTextFile(b, 1).ReadAll())
End Function
