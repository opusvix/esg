@echo off
REM Instalar.bat - instala ou atualiza o OficinaApp neste computador.
REM Dois cliques. Nao precisa de Python nem de permissao de administrador.
title Instalar OficinaApp
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
if errorlevel 1 pause
