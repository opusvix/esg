# ============================================================
# instalar.ps1 - instala ou atualiza o OficinaApp (pacote Windows).
#  - Copia o programa para %LOCALAPPDATA%\Programs\OficinaApp (nao pede
#    permissao de administrador e a pasta aceita gravar o banco).
#  - Atualizacao: troca so o programa. Banco, fotos, backups e o .env
#    (pastas instance e static\uploads) ficam intactos.
#  - Cria o atalho "OficinaApp" na Area de Trabalho e no Menu Iniciar.
#  - Abre o sistema no navegador, sem janela preta.
# Mensagens sem acento de proposito (o console do Windows nem sempre mostra).
# ============================================================
param([string]$Destino = "")

$origem = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($Destino)) {
    $Destino = Join-Path $env:LOCALAPPDATA "Programs\OficinaApp"
}
$Host.UI.RawUI.WindowTitle = "Instalar OficinaApp"

function Linha([string]$t, [string]$cor = "Gray") { Write-Host "  $t" -ForegroundColor $cor }

Write-Host ""
Write-Host "=========================================================="
Write-Host "  OficinaApp - instalacao"
Write-Host "=========================================================="
Write-Host ""

if (-not (Test-Path -LiteralPath (Join-Path $origem "python\pythonw.exe"))) {
    Linha "Este arquivo precisa estar dentro da pasta extraida do .zip." "Red"
    Linha "Extraia o OficinaApp-Windows.zip inteiro (botao direito > Extrair tudo)" "Red"
    Linha "e rode o Instalar.bat de dentro da pasta extraida." "Red"
    exit 1
}

# O .zip veio da internet: o Windows marca os arquivos e o SmartScreen barra o
# programa por nao ter assinatura paga. Somos os autores: tiramos a marca.
Get-ChildItem -LiteralPath $origem -Recurse -File -Force -ErrorAction SilentlyContinue |
    Unblock-File -ErrorAction SilentlyContinue

$atualizacao = Test-Path -LiteralPath (Join-Path $Destino "OficinaApp.vbs")
if ($atualizacao) {
    Linha "Ja existe um OficinaApp em:" "Yellow"
    Linha "  $Destino" "Yellow"
    Linha "Vou ATUALIZAR o programa. Seus dados (clientes, O.S., fotos," "Yellow"
    Linha "backups e senhas) continuam onde estao." "Yellow"
} else {
    Linha "Vou instalar o OficinaApp em:"
    Linha "  $Destino"
}
Write-Host ""
Read-Host "  Tecle ENTER para continuar (ou feche esta janela para cancelar)" | Out-Null

# Sistema aberto? Pede para fechar pelo menu (assim nenhum backup e cortado).
function ProcessosAbertos() {
    $alvo = $Destino.TrimEnd('\') + '\'
    return @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $p = $null
        try { $p = $_.Path } catch { $p = $null }
        $p -and $p.StartsWith($alvo, [StringComparison]::OrdinalIgnoreCase)
    })
}
for ($i = 0; $i -lt 3 -and (ProcessosAbertos).Count -gt 0; $i++) {
    Write-Host ""
    Linha "O OficinaApp esta aberto. No sistema, clique em" "Yellow"
    Linha "'Fechar o sistema' (menu lateral) e depois tecle ENTER aqui." "Yellow"
    Read-Host "  ENTER" | Out-Null
}
$abertos = ProcessosAbertos
if ($abertos.Count -gt 0) {
    Linha "Fechando o OficinaApp para atualizar..." "Yellow"
    $abertos | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
}

# Copia. /MIR deixa o programa igual ao pacote (apaga arquivo velho que saiu
# da versao nova), mas o que esta em /XD e /XF nunca e copiado nem apagado:
# instance (banco, backups, logs), static\uploads (fotos) e o .env.
Write-Host ""
Linha "Copiando o programa..."
New-Item -ItemType Directory -Force -Path $Destino | Out-Null
$robo = @($origem, $Destino, "/MIR", "/R:2", "/W:2",
          "/XD", "instance", "uploads", "__pycache__",
          "/XF", ".env", "Instalar.bat", "instalar.ps1",
          "/NFL", "/NDL", "/NJH", "/NJS", "/NP")
& robocopy @robo | Out-Null
if ($LASTEXITCODE -ge 8) {
    Linha "Nao consegui copiar os arquivos (robocopy codigo $LASTEXITCODE)." "Red"
    Linha "Feche o OficinaApp e rode o Instalar.bat de novo." "Red"
    exit 1
}
New-Item -ItemType Directory -Force -Path (Join-Path $Destino "instance") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Destino "static\uploads") | Out-Null

# Atalhos: Area de Trabalho e Menu Iniciar.
$sh = New-Object -ComObject WScript.Shell
$wscript = Join-Path $env:windir "System32\wscript.exe"
$lugares = @([Environment]::GetFolderPath("Desktop"),
             [Environment]::GetFolderPath("Programs"))
foreach ($lugar in $lugares) {
    if ([string]::IsNullOrEmpty($lugar)) { continue }
    $lnk = $sh.CreateShortcut((Join-Path $lugar "OficinaApp.lnk"))
    $lnk.TargetPath = $wscript
    $lnk.Arguments = '"' + (Join-Path $Destino "OficinaApp.vbs") + '"'
    $lnk.WorkingDirectory = $Destino
    $lnk.IconLocation = (Join-Path $Destino "static\favicon.ico")
    $lnk.Description = "Abre o OficinaApp"
    $lnk.Save()
}

Write-Host ""
Linha "Pronto! O OficinaApp esta instalado." "Green"
Linha "Na Area de Trabalho e no Menu Iniciar ficou o atalho 'OficinaApp'." "Green"
if (-not $atualizacao) {
    Linha "Na primeira vez abre um Bloco de Notas com a senha do administrador." "Green"
}
Linha "Abrindo o sistema no navegador..." "Green"
Start-Process -FilePath $wscript -ArgumentList ('"' + (Join-Path $Destino "OficinaApp.vbs") + '"') -WorkingDirectory $Destino
Start-Sleep -Seconds 4
exit 0
