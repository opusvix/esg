@echo off
REM ============================================================
REM Fechar OficinaApp.bat - encerra o OficinaApp que roda sem janela.
REM O normal e o botao "Fechar o sistema" no menu lateral: ele espera
REM um backup em andamento terminar. Este e so para emergencia
REM (navegador travado). Fica na pasta, sem atalho na Area de Trabalho.
REM ============================================================
set ACHOU=0
for /f "tokens=5" %%p in ('netstat -ano ^| findstr "127.0.0.1:5000" ^| findstr LISTENING') do (
  taskkill /F /PID %%p >nul 2>&1
  set ACHOU=1
)
if "%ACHOU%"=="1" (echo OficinaApp foi fechado.) else (echo O OficinaApp nao estava aberto.)
timeout /t 3 >nul
